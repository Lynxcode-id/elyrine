/*
  ERINE-AI • ELYRINE
  WhatsApp Bot Multi-Device · Node.js ESM

  Developer   Arman Maulana (Lynx decode)
  Versi       1.0.0
  Lisensi     ELYRINE Source-Available Non-Commercial v1.0
  Copyright   © 2026 Arman Maulana

  Didirikan di atas Elyra Labs & ekosistemnya.
  Komunitas   General District (induk) · INF Project · Elyra Labs
  Engine      elyrine-baileys, fork Baileys yang dikustom
              sesuai kebutuhan bot ini.

  Dilarang menjual, menyewakan, atau merebrand tanpa
  izin tertulis dari developer. Jangan hapus kredit ini.
*/

let handler = function (m) {
    let key = {}
    try {
        key.remoteJid = m.quoted ? m.quoted.fakeObj.key.remoteJid : m.key.remoteJid
        key.fromMe = m.quoted ? m.quoted.fakeObj.key.fromMe : m.key.fromMe
        key.id = m.quoted ? m.quoted.fakeObj.key.id : m.key.id
        key.participant = m.quoted ? m.quoted.fakeObj.participant : m.key.participant
    } catch (e) {
        console.error(e)
    }
    conn.sendMessage(m.chat, { delete: key })
}
handler.help = ['delete']
handler.tags = ['info']
handler.command = /^(del|delete|unsend?)$/i
handler.limit = false
handler.admin = true

export default handler
