/*
  ERINE-AI • ELYRINE
  WhatsApp Bot Multi-Device · Node.js ESM

  Developer   Arman Maulana (Lynx decode)
  Versi       1.0.0
  Lisensi     ELYRINE Source-Available Non-Commercial v1.0
  Copyright   © 2026 Arman Maulana

  Didirikan di atas Elyra Labs & ekosistemnya.
  Komunitas   General District (induk) · INF Project · Elyra Labs
  Engine      elyra-baileys, fork Baileys yang dikustom
              sesuai kebutuhan bot ini.

  Dilarang menjual, menyewakan, atau merebrand tanpa
  izin tertulis dari developer. Jangan hapus kredit ini.
*/

import fetch from 'node-fetch';

let handler = async (m, { conn, text, participants, usedPrefix, command }) => {
    if (!text) throw `_Masukan nomor!_\nContoh:\n\n${usedPrefix + command} ${global.owner[0]}`;
    
    await m.wait();
    const _participants = participants.map(user => user.id);
    
    const users = await Promise.all(
        text.split(',')
            .map(v => v.replace(/[^0-9]/g, ''))
            .filter(v => v.length > 4 && v.length < 20 && !_participants.includes(v + '@s.whatsapp.net'))
            .map(async v => {
                const userCheck = await conn.onWhatsApp(v + '@s.whatsapp.net');
                return userCheck[0]?.exists ? v + '@c.us' : null;
            })
    ).then(results => results.filter(Boolean));

    const response = await conn.groupParticipantsUpdate(m.chat, users, "add");

    const pp = await conn.profilePictureUrl(m.chat, 'image').catch(() => null);
    const jpegThumbnail = pp ? Buffer.from(await (await fetch(pp)).arrayBuffer()) : Buffer.alloc(0);

    for (const participant of response) {
        const jid = participant.content.attrs.phone_number;
        const status = participant.status;

        if (status === '408') {
            conn.reply(m.chat, `Tidak dapat menambahkan @${jid.split('@')[0]}!\nMungkin @${jid.split('@')[0]} baru keluar dari grup ini atau dikick`, m);
        } else if (status === '403') {
            const inviteCode = participant.content.content[0].attrs.code;
            const inviteExp = participant.content.content[0].attrs.expiration;
            await m.reply(`Mengundang @${jid.split('@')[0]} menggunakan invite...`);
            
            await conn.sendGroupV4Invite(
                m.chat,
                jid,
                inviteCode,
                inviteExp,
                await conn.getName(m.chat),
                'Undangan untuk bergabung ke grup WhatsApp saya',
                jpegThumbnail
            );
        }
    }
};

handler.help = ['add', '+'].map(v => v + ' @user');
handler.tags = ['group'];
handler.command = /^(add|\+)$/i;
handler.admin = true;
handler.group = true;
handler.botAdmin = true;
handler.fail = null;

export default handler;
